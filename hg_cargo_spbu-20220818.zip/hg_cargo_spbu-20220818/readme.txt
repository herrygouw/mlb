## release to play store         
## applicationId "com.mlbsys.fodi.merchant.fuel"

C:\Program Files (x86)\Java\jdk1.8.0_231\bin\
keytool -genkey -v -dname "CN=fodira,O=MLBsysMerchantFuel,C=Uid" -keystore mykeyMLBsysMerchantFuel.keystore -keysize 1024 -alias flutterMLBmerchantFuel -validity 14000 -keypass 20201001 -storepass 20201001

C:\Program Files (x86)\Java\jdk1.8.0_231\bin\
keytool -importkeystore -srckeystore mykeyMLBsysMerchantFuel.keystore -destkeystore mykeyMLBsysMerchantFuel.keystore -destkeypass 20201001 -deststoretype pkcs12