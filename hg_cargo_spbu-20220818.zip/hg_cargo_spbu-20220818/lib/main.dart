import 'screens/splash_screen.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Fleet Management',
      theme: ThemeData(
          canvasColor: Colors.white,
          fontFamily: 'Swiss',
          primaryColor: Color(0xff343B45), colorScheme: ColorScheme.fromSwatch().copyWith(secondary: Color(0xffFEB940))),
      home: SplashScreen(),
    );
  }
}
