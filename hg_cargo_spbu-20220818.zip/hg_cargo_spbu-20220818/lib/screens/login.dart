import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'home.dart';

import '../utils/constants.dart';
import 'package:odoo_api/odoo_api.dart';
import '../utils/app_shared_pref.dart';
import '../utils/display_dialog.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController _controllerUserName = new TextEditingController();
  TextEditingController _controllerPassword = new TextEditingController();
  var client;

  onErrorOdoo(err) {
    showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        String title =
            (appLANGUAGE == 'id' ? MLBTextsIndo.INFO : MLBTextsEnglish.INFO);
        String message = ((appLANGUAGE == 'id'
                ? MLBTextsIndo.INFO_CONNECTION_PROBLEM
                : MLBTextsEnglish.INFO_CONNECTION_PROBLEM)) +
            '\n\n' +
            err.toString();
        String btnLabel = "OK";
        return new AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            FlatButton(
              child: Text(btnLabel),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        );
      },
    );
  }

  _validasiLogin() {
    _controllerUserName.text = _controllerUserName.text.trim();
    var xusername = _controllerUserName.text.trim();
    var xuserpwd = _controllerPassword.text;
    client = new OdooClient(AppOdoo.odooURL);
    client.authenticate(xusername, xuserpwd, AppOdoo.odooDatabase).then((auth) {
      if (auth.isSuccess) {
        AppSharedPreferences.setUserEmailLoggedIn(_controllerUserName.text);
        AppSharedPreferences.setUserPasswordLoggedIn(_controllerPassword.text);
        AppSharedPreferences.setUserLoggedIn(true);

        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => HomePage()));
      } else {
        displayDialog(context, "Login", "Invalid Login or Password", "OK");
      }
    }).catchError(onErrorOdoo);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff434343),
      body: ListView(
        physics: BouncingScrollPhysics(),
        children: <Widget>[
          SizedBox(
            height: 30,
          ),
          Image.asset(
            'images/logo.png',
            height: 110,
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Fleet',
                style: TextStyle(color: Colors.white, fontSize: 28),
              ),
              Text(
                'Management',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 28),
              ),
            ],
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'for ',
                style: TextStyle(color: Colors.yellow, fontSize: 25),
              ),
              Text(
                'Fuel Merchant',
                style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                    fontSize: 25),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Container(
                width: 80,
                height: 2,
                color: Color(0xffFEB940),
              ),
              Text(
                'Welcome',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 22,
                ),
              ),
              Container(
                width: 80,
                height: 2,
                color: Color(0xffFEB940),
              ),
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Please Enter Your',
                style: TextStyle(color: Colors.white70, fontSize: 22),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Username and Password',
                style: TextStyle(color: Colors.white70, fontSize: 22),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'to sign in',
                style: TextStyle(color: Colors.white70, fontSize: 22),
              ),
            ],
          ),
          Padding(
              padding: EdgeInsets.fromLTRB(27, 15, 27, 1),
              child: Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5.0)),
                child: TextFormField(
                  controller: _controllerUserName,
                  style: TextStyle(color: Color(0xff434343)),
                  decoration: new InputDecoration(
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                    hintStyle: TextStyle(color: Colors.grey, fontSize: 17),
                    hintText: 'Email Address',
                  ),
                ),
              )),
          Padding(
              padding: EdgeInsets.fromLTRB(27, 5, 27, 20),
              child: Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5.0)),
                child: TextFormField(
                  controller: _controllerPassword,
                  obscureText: true,
                  style: TextStyle(color: Color(0xff434343)),
                  decoration: new InputDecoration(
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                    hintStyle: TextStyle(color: Colors.grey, fontSize: 17),
                    hintText: 'Password',
                  ),
                ),
              )),
          Padding(
            padding: EdgeInsets.fromLTRB(30, 10, 30, 0),
            child: InkWell(
              onTap: () {
                _validasiLogin();
              },
              child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    color: Color(0xffFEB940)),
                child: Center(
                  child: Padding(
                    padding: EdgeInsets.only(top: 15, bottom: 15),
                    child: Text(
                      'Login',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
