import 'dart:async';

import '../screens/login.dart';
import 'package:flutter/material.dart';

import '../utils/app_shared_pref.dart';

import '../screens/home.dart';

import 'package:firebase_messaging/firebase_messaging.dart';
//import '../utils/display_dialog.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  String _fcmToken = "";

  @override
  void initState() async {
    super.initState();
    Timer(Duration(seconds: 2), () {
      _handleLogin();
    });

// FCM
    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        print("onMessage: $message");
        //displayDialog(context, "FCM configure", message.toString(), "ok");
      },
      onLaunch: (Map<String, dynamic> message) async {
        print("onLaunch: $message");
        //displayDialog(context, "FCM Launch", message.toString(), "ok");
      },
      onResume: (Map<String, dynamic> message) async {
        print("onResume: $message");
        //displayDialog(context, "FCM Resume", message.toString(), "ok");
      },
    );

    _firebaseMessaging.requestNotificationPermissions(
        const IosNotificationSettings(sound: true, badge: true, alert: true));

    _firebaseMessaging.onIosSettingsRegistered
        .listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
      //displayDialog1(context, "FCM registered", settings.toString(), "ok");
    });

    _firebaseMessaging.getToken().then((String token) {
      assert(token != null);
      setState(() {
        //_fcmToken = "Push Messaging token: $token";
        _fcmToken = "$token";
      });
      print(_fcmToken);
      //displayDialog1(context, "FCM token", _fcmToken.toString(), "ok");

      AppSharedPreferences.setFCM(_fcmToken);
      
    });
  }

  void _handleLogin() async {
    bool isLoggedIn = await AppSharedPreferences.isUserLoggedIn();
    if (isLoggedIn != null && isLoggedIn) {
      setState(() {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => HomePage()));
      });
    } else {
      setState(() {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (c) => LoginScreen()));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff434343),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Image.asset(
            'images/logo.png',
            height: 190,
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Fleet',
                style: TextStyle(color: Colors.white, fontSize: 35),
              ),
              Text(
                'Management',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 35),
              ),
            ],
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'for ',
                style: TextStyle(color: Colors.yellow, fontSize: 25),
              ),
              Text(
                'Fuel Merchant',
                style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                    fontSize: 25),
              ),
            ],
          ),
          SizedBox(
            height: 100,
          ),
        ],
      ),
    );
  }
}
