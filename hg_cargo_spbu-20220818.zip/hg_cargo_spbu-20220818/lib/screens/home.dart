import 'dart:ui';
import 'dart:async';
import 'package:intl/intl.dart';
import 'dart:convert';

import 'package:barcode_scan_example/utils/display_dialog.dart';
import 'package:flutter_native_timezone/flutter_native_timezone.dart';
import 'package:flutter_multi_formatter/flutter_multi_formatter.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/app_shared_pref.dart';

import '../utils/constants.dart';
import 'package:odoo_api/odoo_api.dart';

import 'package:barcode_scan/barcode_scan.dart';
import 'package:image_picker/image_picker.dart';

import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:package_info/package_info.dart';
import 'package:url_launcher/url_launcher.dart';

import 'document_list.dart';

//import '../helpers.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<int, Widget> mainView;

  int _user_id = 0;

  String _timezone = 'Unknown';
  String _partnerName = '';
  String _partnerImageBase64 = '';

  bool bFirstTime = true;

  final _flashOnController = TextEditingController(text: "Flash on");
  final _flashOffController = TextEditingController(text: "Flash off");
  final _cancelController = TextEditingController(text: "Cancel");

  var _aspectTolerance = 0.00;
  var _selectedCamera = -1;
  var _useAutoFocus = true;
  var _autoEnableFlash = false;

  ScanResult scanResult;

  List<String> xdataScanResult;

  bool bvalidFuelVoucher = false;
  String validFuelVoucherMessage = '';

  bool bsuccessUsedFuelVoucher = false;
  String successUsedFuelVoucherMessage = '';

  TextEditingController _controllerUsedFuel = new TextEditingController();
  TextEditingController _controllerReceiptNo = new TextEditingController();
  String base64ImagePhotoReceipt = '';

  double latitude = 0.0;
  double longitude = 0.0;

  @override
  void initState() {
    super.initState();
    
    initPlatformState();
    _initPackageInfo();

    try {
      _getPartnerId();
      //_updatFCM();
    } catch (Exception) {}
  }

  initPlatformState() async {
    String xtimezone = '';
    try {
      xtimezone = await FlutterNativeTimezone.getLocalTimezone();
    } on PlatformException {
      xtimezone = 'Failed to get the timezone.';
    }
    setState(() {
      _timezone = xtimezone;
    });
  }


  _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  Future<void> _initPackageInfo() async {
    //Get Current installed version of app
    final PackageInfo info = await PackageInfo.fromPlatform();
    //double currentVersion = double.parse(info.version.trim().replaceAll(".", ""));
    double currentVersion =
        double.parse(info.buildNumber.trim().replaceAll(".", ""));

    //displayDialog(context, "apk build number", currentVersion.toString(), "OK");
    // _showVersionDialog(context);

    //Get Latest version info from firebase config
    final RemoteConfig remoteConfig = await RemoteConfig.instance;

    try {
      // Using default duration to force fetching from remote server.
      await remoteConfig.fetch(expiration: const Duration(seconds: 0));
      await remoteConfig.activateFetched();
      //remoteConfig.getString('force__current_version');
      //remoteConfig.getString('force_update_current_version_code');
      double newVersion = 0;

      if (AppOdoo.odooURL == "https://www.keepsense.com")
        newVersion = double.parse(remoteConfig
            .getString('force_update_current_version_code_mlb_fuel')
            .trim()
            .replaceAll(".", ""));
      else
        newVersion = double.parse(remoteConfig
            .getString('force_update_current_version_code_dev_mlb_fuel')
            .trim()
            .replaceAll(".", ""));

      // displayDialog(context, "google build numberx", remoteConfig
      //     .getString('force_update_current_version_code')
      //     .trim()
      //     .replaceAll(".", ""), "OK");
      //displayDialog(context, "google build number", newVersion.toString(), "OK");
      if (newVersion > currentVersion) {
        //_showVersionDialog(context);
        _launchURL(AppStore.PLAY_STORE_URL);
        // CLOSE THE APPS
        SystemChannels.platform.invokeMethod('SystemNavigator.pop');
        //_launchURL(AppStore.PLAY_STORE_URL);
      }
    } on FetchThrottledException catch (exception) {
      // Fetch throttled.
      displayDialog(context, "exception", exception.toString(), "OK");
      //print(exception);
    } catch (exception) {
      displayDialog(
          context,
          "catch",
          "Unable to fetch remote config. Cached or default values will be used",
          "OK");
      // print('Unable to fetch remote config. Cached or default values will be '
      //     'used');
    }
  }


  onErrorOdoo(err) {
    showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        String title =
            (appLANGUAGE == 'id' ? MLBTextsIndo.INFO : MLBTextsEnglish.INFO);
        String message = ((appLANGUAGE == 'id'
                ? MLBTextsIndo.INFO_CONNECTION_PROBLEM
                : MLBTextsEnglish.INFO_CONNECTION_PROBLEM)) +
            '\n\n' +
            err.toString();
        String btnLabel = "OK";
        return new AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            FlatButton(
              child: Text(btnLabel),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        );
      },
    );
  }


  _updatFCM() async {

    var xusername;
    var xuserpwd;

    var xFcmToken;

    String getuserEmailLoggedIn =
        await AppSharedPreferences.getUserEmailLoggedIn();
    if (getuserEmailLoggedIn != null && getuserEmailLoggedIn.length > 0) {
      xusername = getuserEmailLoggedIn;
    }
    String getuserPasswordLoggedIn =
        await AppSharedPreferences.getUserPasswordLoggedIn();
    if (getuserPasswordLoggedIn != null && getuserPasswordLoggedIn.length > 0) {
      xuserpwd = getuserPasswordLoggedIn;
    }

    String getFCM =
        await AppSharedPreferences.getFCM();
    if (getFCM != null && getFCM.length > 0) {
      xFcmToken = getFCM;
    }

    var client = new OdooClient(AppOdoo.odooURL);
    client.authenticate(xusername, xuserpwd, AppOdoo.odooDatabase).then((auth) {
      if (auth.isSuccess) {
        //displayDialog(context, "get_trip_fuel_voucher", tripId.toString(), "OK");

        var argsApi = [
          null,
          {
            "user_id": _user_id,
            "fcm_token": xFcmToken,
          },
        ];

        client.callKW("driver.api", "update_fcm_token", argsApi,
            kwargs: {}, context: {}).then((resultApi) {
          if (!resultApi.hasError()) {
            final dynamic dataApi = resultApi.getResult();

            // displayDialog(
            //     context, "update_fcm_token", dataApi.toString(), "OK");

            // if (dataApi[0]['status'].toString() == "1") {
            // }

            //displayDialog(context, "Information", dataApi.toString(), "OK");
          } else {
            displayDialog(
                context, "update_fcm_token", resultApi.toString(), "OK");
          }
        }).catchError(onErrorOdoo);
      }
    }).catchError(onErrorOdoo);
  }

  _getPartnerId() async {
    if (!bFirstTime) return;

    var xusername;
    var xuserpwd;

    String getuserEmailLoggedIn =
        await AppSharedPreferences.getUserEmailLoggedIn();
    if (getuserEmailLoggedIn != null && getuserEmailLoggedIn.length > 0) {
      xusername = getuserEmailLoggedIn;
    }
    String getuserPasswordLoggedIn =
        await AppSharedPreferences.getUserPasswordLoggedIn();
    if (getuserPasswordLoggedIn != null && getuserPasswordLoggedIn.length > 0) {
      xuserpwd = getuserPasswordLoggedIn;
    }

    var xFcmToken = '';
    
    String getFCM =
        await AppSharedPreferences.getFCM();
    if (getFCM != null && getFCM.length > 0) {
      xFcmToken = getFCM;
    }

    var client = new OdooClient(AppOdoo.odooURL);
    client.authenticate(xusername, xuserpwd, AppOdoo.odooDatabase).then((auth) {
      if (auth.isSuccess) {

        setState(() {
          _user_id = int.parse(auth.getUser().uid.toString());  
        });

        final domain01 = [
          ["id", "=", int.parse(auth.getUser().uid.toString())],
        ];
        final fields01 = [
          "id",
          "name",
          "partner_id",
        ];

        client
            .searchRead("res.users", domain01, fields01,
                limit: 1, offset: 0, order: "name")
            .then((result) {
          if (!result.hasError()) {
            final dynamic data = result.getResult();

            //displayDialog(context, "res.users", data.toString(), "OK");

            final domain01 = [
              [
                "id",
                "=",
                data['records'][0]['partner_id'][0],
              ]
            ];
            final fields01 = [
              "id",
              "name",
              "transportation_position",
              "image_1920",
            ];

            client
                .searchRead("res.partner", domain01, fields01,
                    limit: 1, offset: 0, order: "id")
                .then((result) {
              if (!result.hasError()) {
                final dynamic data = result.getResult();

                //displayDialog(context, "res.partner", data.toString(), "OK");

                AppSharedPreferences.setPartnerId(
                    data['records'][0]['id'].toString());

                setState(() {
                  bFirstTime = false;
                  _partnerName = data['records'][0]['name'].toString();
                  if (data['records'][0]['image_1920'] == null)
                    _partnerImageBase64 = '';
                  else
                    _partnerImageBase64 = data['records'][0]['image_1920'].toString();
                });

                // UPDATE FCM TOKEN
                var argsApi = [
                  null,
                  {
                    "user_id": _user_id,
                    "fcm_token": xFcmToken,
                  },
                ];

                client.callKW("driver.api", "update_fcm_token", argsApi,
                    kwargs: {}, context: {}).then((resultApi) {
                  if (!resultApi.hasError()) {
                    final dynamic dataApi = resultApi.getResult();

                    // displayDialog(
                    //     context, "update_fcm_token", dataApi.toString(), "OK");

                    // if (dataApi[0]['status'].toString() == "1") {
                    // }

                    //displayDialog(context, "Information", dataApi.toString(), "OK");
                  } else {
                    displayDialog(
                        context, "update_fcm_token", resultApi.toString(), "OK");
                  }
                }).catchError(onErrorOdoo);


              }
            }); //.catchError(onErrorOdoo);
          }
        }); //.catchError(onErrorOdoo);
      }
    }).catchError(onErrorOdoo);
  }

  Future scanQR() async {
    setState(() {
      xdataScanResult = null;
      base64ImagePhotoReceipt = '';      
      _controllerUsedFuel.text = '';
      _controllerReceiptNo.text = '';
    });

    try {
      var options = ScanOptions(
        strings: {
          "cancel": _cancelController.text,
          "flash_on": _flashOnController.text,
          "flash_off": _flashOffController.text,
        },
        //restrictFormat: null,
        useCamera: _selectedCamera,
        autoEnableFlash: _autoEnableFlash,
        android: AndroidOptions(
          aspectTolerance: _aspectTolerance,
          useAutoFocus: _useAutoFocus,
        ),
      );

      var result = await BarcodeScanner.scan(options: options);

      setState(() => scanResult = result);

      if (scanResult != null) if (scanResult.rawContent.length > 0) {
        setState(() {
          xdataScanResult = scanResult.rawContent.split("|");
        });
        if (xdataScanResult.length > 0) {
          //displayDialog(context, "QR", scanResult.rawContent, "OK");

          _controllerUsedFuel.text = xdataScanResult[2].toString();

          String getpartnerid = await AppSharedPreferences.getPartnerId();
          if (getpartnerid == null) return;

          _validateFuelVoucher(int.parse(xdataScanResult[0].toString()),
              int.parse(getpartnerid));
        }
      }
    } on PlatformException catch (e) {
      var result = ScanResult(
        type: ResultType.Error,
        format: BarcodeFormat.unknown,
      );

      if (e.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          result.rawContent = 'The user did not grant the camera permission!';
        });
      } else {
        result.rawContent = 'Unknown error: $e';
      }
      setState(() {
        scanResult = result;
      });
    }
  }

  _validateFuelVoucher(int fuelId, int spbuId) async {
    setState(() {
      bvalidFuelVoucher = false;
    });

    var xusername;
    var xuserpwd;

    String getuserEmailLoggedIn =
        await AppSharedPreferences.getUserEmailLoggedIn();
    if (getuserEmailLoggedIn != null && getuserEmailLoggedIn.length > 0) {
      xusername = getuserEmailLoggedIn;
    }
    String getuserPasswordLoggedIn =
        await AppSharedPreferences.getUserPasswordLoggedIn();
    if (getuserPasswordLoggedIn != null && getuserPasswordLoggedIn.length > 0) {
      xuserpwd = getuserPasswordLoggedIn;
    }

    var client = new OdooClient(AppOdoo.odooURL);
    client.authenticate(xusername, xuserpwd, AppOdoo.odooDatabase).then((auth) {
      if (auth.isSuccess) {
        //displayDialog(context, "get_trip_fuel_voucher", tripId.toString(), "OK");

        var argsApi = [
          null,
          {
            "fuel_id": fuelId,
            "spbu_id": spbuId,
          },
        ];

        client.callKW("driver.api", "validate_fuel_voucher", argsApi,
            kwargs: {}, context: {}).then((resultApi) {
          if (!resultApi.hasError()) {
            final dynamic dataApi = resultApi.getResult();

            // displayDialog(
            //     context, "validate_fuel_voucher", dataApi.toString(), "OK");

            if (dataApi[0]['status'].toString() == "1") {
              setState(() {
                bvalidFuelVoucher = true;
              });

            }

            setState(() {
              validFuelVoucherMessage = dataApi[0]['message'].toString();
            });

            //displayDialog(context, "Information", dataApi.toString(), "OK");
          } else {
            displayDialog(
                context, "validate_fuel_voucher", resultApi.toString(), "OK");
          }
        }).catchError(onErrorOdoo);
      }
    }).catchError(onErrorOdoo);
  }

  _usedFuelVoucher(int fuelId, int spbuId) async {
    if (!bvalidFuelVoucher) return;

    if (_controllerUsedFuel.text.length == 0) return;

    if (_controllerReceiptNo.text.length == 0) return;

    setState(() {
      bsuccessUsedFuelVoucher = false;
    });

    var xusername;
    var xuserpwd;

    String getuserEmailLoggedIn =
        await AppSharedPreferences.getUserEmailLoggedIn();
    if (getuserEmailLoggedIn != null && getuserEmailLoggedIn.length > 0) {
      xusername = getuserEmailLoggedIn;
    }
    String getuserPasswordLoggedIn =
        await AppSharedPreferences.getUserPasswordLoggedIn();
    if (getuserPasswordLoggedIn != null && getuserPasswordLoggedIn.length > 0) {
      xuserpwd = getuserPasswordLoggedIn;
    }

    var client = new OdooClient(AppOdoo.odooURL);
    client.authenticate(xusername, xuserpwd, AppOdoo.odooDatabase).then((auth) {
      if (auth.isSuccess) {
        //displayDialog(context, "get_trip_fuel_voucher", tripId.toString(), "OK");

        var argsApi = [
          null,
          {
            "fuel_id": fuelId,
            "spbu_id": spbuId,
            "used_quantity": int.parse(_controllerUsedFuel.text),
            "receipt_no": int.parse(_controllerReceiptNo.text),
            "receipt_image": base64ImagePhotoReceipt,
            "transaction_time":
                DateFormat('yyyy-MM-dd H:mm:ss').format(DateTime.now().toUtc()),
            "transaction_latitude": 0.0,
            "transaction_longitude": 0.0,
          },
        ];

        client.callKW("driver.api", "used_fuel_voucher", argsApi,
            kwargs: {}, context: {}).then((resultApi) {
          if (!resultApi.hasError()) {
            final dynamic dataApi = resultApi.getResult();

            // displayDialog(
            //     context, "used_fuel_voucher", dataApi.toString(), "OK");

            if (dataApi[0]['status'].toString() == "1") {
              setState(() {
                bsuccessUsedFuelVoucher = true;
              });

              // refresh 
              setState(() {
                xdataScanResult = null;
                base64ImagePhotoReceipt = '';      
                _controllerUsedFuel.text = '';
                _controllerReceiptNo.text = '';
              });
            }

            setState(() {
              successUsedFuelVoucherMessage = dataApi[0]['message'].toString();
            });

            displayDialog(context, "Used Fuel Voucher", successUsedFuelVoucherMessage, "OK");

          } else {
            displayDialog(
                context, "used_fuel_voucher", resultApi.toString(), "OK");
          }
        }).catchError(onErrorOdoo);
      }
    }).catchError(onErrorOdoo);


    // if (xdataScanResult == null)
    // {
    //     setState(() {
    //       bFirstTime = true;
    //     });
    //     try {
    //       _getPartnerId();
    //     } catch (Exception) {}

    //     Navigator.pushReplacement(
    //       context, MaterialPageRoute(builder: (context) => HomePage()));

    // }

    Navigator.pushReplacement(
      context, MaterialPageRoute(builder: (context) => HomePage()));

  }

  getImageFPhotoReceipt(ImageSource source) async {
    var imagePhotoReceipt = await ImagePicker.pickImage(
        source: source, imageQuality: 50, maxHeight: 600.0, maxWidth: 800.0);

    List<int> imageBytesPhotoReceipt = imagePhotoReceipt.readAsBytesSync();
    var xbase64ImagePhotoReceipt = base64Encode(imageBytesPhotoReceipt);

    setState(() {
      base64ImagePhotoReceipt = xbase64ImagePhotoReceipt;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (bFirstTime) {
      try {
        _getPartnerId();
      } catch (Exception) {}
    }

    return Scaffold(
      backgroundColor: Color(0xff1C1F24),
      appBar: AppBar(
        primary: true,
        centerTitle: true,
        backgroundColor: Colors.transparent,
        title: Text("Main Menu"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // scan QR
          scanQR();
        },
        child: Icon(
          Icons.wallpaper,
          color: Colors.white,
        ),
      ),
      drawer: Theme(
        data: Theme.of(context).copyWith(
            canvasColor: Colors.white.withOpacity(0.8),
            brightness: Brightness.light),
        child: Drawer(
          child: makeDrawer(context),
        ),
      ),
      body: ListView(
        scrollDirection: Axis.vertical,
        children: <Widget>[
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'Silahkan Klik Icon Scan QR di kanan bawah',
                            style: TextStyle(
                              color: Colors.yellowAccent,
                              fontSize: 20.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: scanResult == null
                ? true
                : scanResult.rawContent.length == 0 ? true : false,
          ),
          Container(
            height: 20,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            scanResult != null
                                ? scanResult.rawContent.length > 0
                                    ? validFuelVoucherMessage
                                    : ''
                                : '',
                            style: TextStyle(color: Colors.red, fontSize: 32.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: !bvalidFuelVoucher && scanResult != null,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'VEHICLE',
                            style: TextStyle(
                              color: Colors.lightGreenAccent,
                              fontSize: 30.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            xdataScanResult == null
                                ? ''
                                : xdataScanResult[5].toString(),
                            style:
                                TextStyle(color: Colors.yellow, fontSize: 32.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: scanResult == null
                ? false
                : scanResult.rawContent.length == 0
                    ? false
                    : bvalidFuelVoucher ? true : false,
          ),
          Container(
            height: 10,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'FUEL',
                            style: TextStyle(
                              color: Colors.lightGreenAccent,
                              fontSize: 30.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            xdataScanResult == null
                                ? ''
                                : xdataScanResult[1].toString(),
                            style:
                                TextStyle(color: Colors.yellow, fontSize: 32.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: scanResult == null
                ? false
                : scanResult.rawContent.length == 0
                    ? false
                    : bvalidFuelVoucher ? true : false,
          ),
          Container(
            height: 10,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'ALLOCATION',
                            style: TextStyle(
                              color: Colors.lightGreenAccent,
                              fontSize: 30.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            xdataScanResult == null
                                ? ''
                                : xdataScanResult[2].toString(),
                            style:
                                TextStyle(color: Colors.yellow, fontSize: 32.0),
                          ),
                          // Container(
                          //   height: 35.0,
                          // ),
                          // GestureDetector(
                          //   onTap: () {},
                          //   child: Container(
                          //       decoration: BoxDecoration(
                          //           border: Border.all(
                          //               width: 1, color: Colors.green),
                          //           borderRadius:
                          //               BorderRadius.all(Radius.circular(50))),
                          //       child: Padding(
                          //         padding: EdgeInsets.all(7),
                          //         child: Icon(
                          //           Icons.done,
                          //           color: Colors.lightGreenAccent,
                          //         ),
                          //       )),
                          // ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: scanResult == null
                ? false
                : scanResult.rawContent.length == 0
                    ? false
                    : bvalidFuelVoucher ? true : false,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'USED QUANTITY',
                            style: TextStyle(
                              color: Colors.lightGreenAccent,
                              fontSize: 30.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          TextField(
                            controller: _controllerUsedFuel,
                            textAlign: TextAlign.center,
                            // inputFormatters: [
                            //   WhitelistingTextInputFormatter.digitsOnly
                            // ],
                            inputFormatters: [
                              MoneyInputFormatter(
                                //leadingSymbol: MoneySymbols.DOLLAR_SIGN,
                                //useSymbolPadding: true,
                                mantissaLength: 0,
                                thousandSeparator:
                                    ThousandSeparator.Period,
                              )
                            ],
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                            ),
                            keyboardType: TextInputType.number,
                            // onChanged: (String value) => setState(() {}),
                            onChanged: (String val) {
                              val = val.replaceAll('.', '');
                              setState(() {
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: scanResult == null
                ? false
                : scanResult.rawContent.length == 0
                    ? false
                    : bvalidFuelVoucher ? true : false,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'PHOTO RECEIPT',
                            style: TextStyle(
                              color: Colors.lightGreenAccent,
                              fontSize: 30.0,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              // TAKE CAMERA PHOTO RECEIPT
                              getImageFPhotoReceipt(ImageSource.camera);
                            },
                            child: Container(
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 1, color: Colors.grey),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(50))),
                                child: Padding(
                                  padding: EdgeInsets.all(7),
                                  child: Icon(
                                    Icons.camera,
                                    color: Color(0xffFEB940),
                                  ),
                                )),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          base64ImagePhotoReceipt.length > 0
                              ? Image.memory(
                                  base64.decode(base64ImagePhotoReceipt))
                              : Text('NO IMAGE'),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: scanResult == null
                ? false
                : scanResult.rawContent.length == 0
                    ? false
                    : bvalidFuelVoucher ? true : false,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'RECEIPT NUMBER',
                            style: TextStyle(
                              color: Colors.lightGreenAccent,
                              fontSize: 30.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          TextField(
                            textAlign: TextAlign.center,
                            controller: _controllerReceiptNo,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                            ),
                            keyboardType: TextInputType.text,
                            onChanged: (String value) => setState(() {}),
                          ),
                          Container(
                            height: 35.0,
                          ),
                          GestureDetector(
                            onTap: () async {
                              // API USED FUEL VOUCHER
                              String getpartnerid = await AppSharedPreferences.getPartnerId();
                              if (getpartnerid == null) return;

                              if (base64ImagePhotoReceipt.length == 0)
                              {
                                  displayDialog(context, "Perhatian", "Photo Struk harus terisi", "OK");
                                  return;
                              }

                              _usedFuelVoucher(int.parse(xdataScanResult[0].toString()),
                                  int.parse(getpartnerid));

                            },
                            child: Container(
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 1, color: Colors.green),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(50))),
                                child: Padding(
                                  padding: EdgeInsets.all(7),
                                  child: Icon(
                                    Icons.done,
                                    color: Colors.lightGreenAccent,
                                  ),
                                )),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: scanResult == null
                ? false
                : scanResult.rawContent.length == 0
                    ? false
                    : bvalidFuelVoucher ? true : false,
          ),
        ],
      ),
    );
  }

  var drawerList = TextStyle(fontWeight: FontWeight.bold, fontSize: 19);

  makeDrawer(BuildContext context) {
    return ClipRect(
        child: BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 0),
        child: ListView(
          shrinkWrap: true,
          children: <Widget>[
            Padding(
                padding: EdgeInsets.only(top: 20, bottom: 10),
                child: Container(
                  height: 90,
                  child: CircleAvatar(
                    radius: 18,
                    child: ClipOval(
                      // foto driver
                      child: 
                        _partnerImageBase64.length < 1 ?
                        Image.asset(
                          'images/default_image.png',
                        ) 
                        : Image.memory(
                          base64Decode(_partnerImageBase64),
                          width: 100.0,
                          height: 100.0,
                          //fit: BoxFit.fitWidth,
                        ),
                    ),
                  ),
                )),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  _partnerName,
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Mitra Lintas Borneo',
                  style: TextStyle(fontSize: 18, color: Colors.grey),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Build 2022.06.11.001 (mlbsys-mockrun2)',
                  style: TextStyle(fontSize: 12, color: Colors.red),
                )
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Timezone: ' + _timezone,
                  style: TextStyle(fontSize: 18, color: Colors.grey),
                )
              ],
            ),
            SizedBox(
              height: 20,
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  bFirstTime = true;
                });
                try {
                  _getPartnerId();
                } catch (Exception) {}

                Navigator.pop(context);
              },
              child: Padding(
                padding: EdgeInsets.only(top: 10, bottom: 10),
                child: Row(
                  children: <Widget>[
                    Icon(
                      Icons.home,
                      color: Color(0xffFEB940),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Text(
                      'Home',
                      style: drawerList,
                    )
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            GestureDetector(
                onTap: () {
                  // Document List
                  Navigator.push(
                    context, MaterialPageRoute(builder: (context) => DocumentList()));
                },
                child: Padding(
                  padding: EdgeInsets.only(top: 10, bottom: 10),
                  child: Row(
                    children: <Widget>[
                      Icon(
                        Icons.person,
                        color: Color(0xffFEB940),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        'Document List',
                        style: drawerList,
                      )
                    ],
                  ),
                )),
            SizedBox(
              height: 10,
            ),
            GestureDetector(
              onTap: () {
                AppSharedPreferences.clear();
                SystemChannels.platform.invokeMethod('SystemNavigator.pop');
              },
              child: Padding(
                padding: EdgeInsets.only(top: 10, bottom: 10),
                child: Row(
                  children: <Widget>[
                    Icon(
                      Icons.exit_to_app,
                      color: Color(0xffFEB940),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Text(
                      'Logout',
                      style: drawerList,
                    )
                  ],
                ),
              ),
            ),
          ],
          physics: BouncingScrollPhysics(),
        ),
      ),
    ));
  }
}
