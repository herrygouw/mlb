import 'dart:convert';
import 'package:intl/intl.dart';

import 'package:flutter/material.dart';

import '../utils/app_shared_pref.dart';
import '../utils/constants.dart';
import 'package:odoo_api/odoo_api.dart';
//import '../utils/display_dialog.dart';

import 'package:flutter_rounded_date_picker/rounded_picker.dart';
//import 'package:date_format/date_format.dart';

import '../data/list_document.dart';
//import 'dart:convert';
//import 'package:qr_flutter/qr_flutter.dart';

//import 'document_scan.dart';

import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'document_pdf.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:date_format/date_format.dart';

class DocumentList extends StatefulWidget {
  @override
  _DocumentListState createState() => _DocumentListState();
}

class _DocumentListState extends State<DocumentList> {
  ListDocument modelListDocument = new ListDocument();

  ScrollController _scrollListDocument = new ScrollController();

  DateTime _newDateTime;

  int rowListDocumentDetail = -1;

  var f = new NumberFormat("###.0#", "en_US");

  final GlobalKey<State<StatefulWidget>> shareWidget = GlobalKey();

  @override
  void initState() {
    super.initState();

    _newDateTime = null;

    try {
      _getListDocument();
    } catch (Exception) {}
  }

  _getListDocument() async {
    // // DateTime newDateTime = await showRoundedDatePicker(
    // //     borderRadius: 16,
    // //     initialDate: DateTime.now(),
    // //     context: context,
    // //     theme: ThemeData.dark(),
    // //     //textActionButton: "ACTION",
    // //     onTapActionButton: () {
    // //       //displayDialog(context, "Date", "action", "OK");
    // //       //xPickDate = 1;
    // //     },
    // //     textPositiveButton: "OK",
    // //     textNegativeButton: "CANCEL");

    // // if (newDateTime == null) newDateTime = DateTime.now();
    // // setState(() {
    // //   _newDateTime = newDateTime;
    // // });

    // final DateTime selected = await showDatePicker(
    //     context: context,
    //     initialDate: _newDateTime,
    //     firstDate: DateTime(2010),
    //     lastDate: DateTime(2025), 
    //     helpText: "SELECT DATE",
    //     cancelText: "CANCEL",
    //     confirmText: "OK",
    //     fieldHintText: "DATE/MONTH/YEAR",
    //     fieldLabelText: "SELECT DATE",        
    //   );

    // if (selected != null && selected != _newDateTime)
    //   setState(() {
    //     _newDateTime = selected;
    // });

    // if (selected == null) 
    //   setState(() {
    //     _newDateTime = DateTime.now();
    //   });

    DateTime newDateTime = await showRoundedDatePicker(
        borderRadius: 16,
        initialDate: DateTime.now(),
        context: context,
        theme: ThemeData.dark(),
        //textActionButton: "ACTION",
        onTapActionButton: () {
          //displayDialog(context, "Date", "action", "OK");
          //xPickDate = 1;
        },
        textPositiveButton: "OK",
        textNegativeButton: "CANCEL");

    if (newDateTime == null) newDateTime = DateTime.now();
    setState(() {
      _newDateTime = newDateTime;
    });

    setState(() {
      rowListDocumentDetail = -1;
    });

    var xusername;
    var xuserpwd;
    int xpartnerid;

    String getuserEmailLoggedIn =
        await AppSharedPreferences.getUserEmailLoggedIn();
    if (getuserEmailLoggedIn != null && getuserEmailLoggedIn.length > 0) {
      xusername = getuserEmailLoggedIn;
    }
    String getuserPasswordLoggedIn =
        await AppSharedPreferences.getUserPasswordLoggedIn();
    if (getuserPasswordLoggedIn != null && getuserPasswordLoggedIn.length > 0) {
      xuserpwd = getuserPasswordLoggedIn;
    }

    String getpartnerid = await AppSharedPreferences.getPartnerId();
    if (getpartnerid == null) return;

    xpartnerid = int.parse(getpartnerid);

    // DateTime xxfr = DateTime.parse(
    //     formatDate(_newDateTime, [yyyy, '-', mm, '-', dd]) + " 00:00:00");
    // DateTime xxto = xxfr.add(new Duration(hours: 24));

    var client = new OdooClient(AppOdoo.odooURL);
    client.authenticate(xusername, xuserpwd, AppOdoo.odooDatabase).then((auth) {
      if (auth.isSuccess) {
        var argsApi = [
          null,
          {
            "spbu_id": xpartnerid,
            "date": _newDateTime.year.toString() +
                '-' +
                _newDateTime.month.toString() +
                '-' +
                _newDateTime.day.toString(),
            "offset": 0,
            "limit": 0,
          },
        ];

        //displayDialog(context, "get_fuel_transaction_list", xpartnerid.toString(), "OK");

        client.callKW("driver.api", "get_fuel_transaction_list", argsApi,
            kwargs: {}, context: {}).then((resultApi) {
          if (!resultApi.hasError()) {
            final dynamic dataApi = resultApi.getResult();
            //displayDialog(context, "get_fuel_transaction_list", dataApi[0]['length'].toString(), "OK");

            // //displayDialog(context, "get_fuel_transaction_list => length", dataApi[0]['length'].toString(), "OK");

            modelListDocument.clear();

            if (dataApi[0]['length'].toString() != "0") {
              int i = 0;
              try {
                while (i < int.parse(dataApi[0]['length'].toString())) {
                  modelListDocument.addItem(
                    dataApi[0]['data'][i]['id'].toString(),
                    dataApi[0]['data'][i]['name'].toString(),
                    dataApi[0]['data'][i]['vehicle'].toString(),
                    dataApi[0]['data'][i]['driver'].toString(),
                    dataApi[0]['data'][i]['fuel_name'].toString(),
                    dataApi[0]['data'][i]['used_quantity'].toString(),
                    dataApi[0]['data'][i]['fuel_price'].toString(),
                    dataApi[0]['data'][i]['amount'].toString(),
                    dataApi[0]['data'][i]['transaction_time'].toString(),
                    dataApi[0]['data'][i]['receipt_no'].toString(),
                    dataApi[0]['data'][i]['receipt_image'].toString(),
                  );
                  i++;
                }
              } catch (Exception) {}
            }

            setState(() {});

            //displayDialog(context, "get_fuel_transaction_list", modelListDocument.itemCount.toString(), "OK");

          } else {
            //displayDialog(context, "get_trip", resultApi.toString(), "OK");
          }
        }); //.catchError(onErrorOdoo);
      }
    }); //.catchError(onErrorOdoo);
  }

  void _showPrintedToast(bool printed) {
    final ScaffoldState scaffold = Scaffold.of(shareWidget.currentContext);
    if (printed) {
      scaffold.showSnackBar(const SnackBar(
        content: Text('Document printed successfully'),
      ));
    } else {
      scaffold.showSnackBar(const SnackBar(
        content: Text('Document not printed'),
      ));
    }
  }

  Future<void> _printHtml() async {
    print('Print html ...');

    String isiDetailReport = "";

    double gtotal = 0;
    for (var i = 0; i < modelListDocument.itemCount; i++) {
      isiDetailReport += "<tr>";
      isiDetailReport += "<td>";
      isiDetailReport += modelListDocument.items.values.toList()[i].receiptNo;
      isiDetailReport += "</td>";
      isiDetailReport += "<td>";
      isiDetailReport += modelListDocument.items.values
          .toList()[i]
          .transactionTime
          .substring(11);
      isiDetailReport += "</td>";
      isiDetailReport += "<td align='right'>";
      double yqty =
          double.parse(modelListDocument.items.values.toList()[i].usedQuantity);
      FlutterMoneyFormatter fmfqty = FlutterMoneyFormatter(amount: yqty);
      MoneyFormatterOutput foqty = fmfqty.output;
      isiDetailReport +=
          (foqty.nonSymbol).replaceAll('.00', '').replaceAll(',', '.');
      isiDetailReport += "</td>";
      isiDetailReport += "<td align='right'>";
      double yamt =
          double.parse(modelListDocument.items.values.toList()[i].fuelPrice);
      FlutterMoneyFormatter fmfamt = FlutterMoneyFormatter(amount: yamt);
      MoneyFormatterOutput foamt = fmfamt.output;
      isiDetailReport +=
          (foamt.nonSymbol).replaceAll('.00', '').replaceAll(',', '.') + ',-';
      isiDetailReport += "</td>";
      isiDetailReport += "<td align='right'>";
      double ytotal =
          double.parse(modelListDocument.items.values.toList()[i].amount);
      gtotal += ytotal;
      FlutterMoneyFormatter fmf = FlutterMoneyFormatter(amount: ytotal);
      MoneyFormatterOutput fo = fmf.output;
      isiDetailReport +=
          (fo.nonSymbol).replaceAll('.00', '').replaceAll(',', '.') + ',-';
      isiDetailReport += "</td>";
      isiDetailReport += "<td>";
      isiDetailReport += modelListDocument.items.values.toList()[i].name;
      isiDetailReport += "</td>";
      isiDetailReport += "<td>";
      isiDetailReport += modelListDocument.items.values.toList()[i].driver;
      isiDetailReport += "</td>";
      isiDetailReport += "<td>";
      isiDetailReport += modelListDocument.items.values.toList()[i].vehicle;
      isiDetailReport += "</td>";
      isiDetailReport += "</tr>";
    }
    FlutterMoneyFormatter fmf = FlutterMoneyFormatter(amount: gtotal);
    MoneyFormatterOutput fo = fmf.output;
    isiDetailReport += "<tr>";
    isiDetailReport += "<td colspan='5' align='right'>";
    isiDetailReport += "TOTAL Rp. " +
        (fo.nonSymbol).replaceAll('.00', '').replaceAll(',', '.') +
        ',-';
    ;
    isiDetailReport += "</td>";
    isiDetailReport += "</tr>";

    //var document = parse(
    String document = """
<html>
<head>
  <style>
    * {
      font-family: Arial, Helvetica, sans-serif;
    }
    table,
    th,
    td {
      border: 1px solid black;
      border-collapse: collapse;
    }
    th,
    td {
      padding: 5px;
    }
  </style>
</head>
<body>
  <h2>Fuel Transaction</h2>
  <caption>Date: """ +
        formatDate(_newDateTime, [dd, '-', M, '-', yyyy]) +
        """</caption>
  <table>
    <tr>
      <th>Receipt No.</th>
      <th>Time</th>
      <th align='right'>Qty</th>
      <th align='right'>Amount</th>
      <th align='right'>Total</th>
      <th>Doc.Name</th>
      <th>Driver</th>
      <th>Plate No.</th>
    </tr>
    """ +
        isiDetailReport +
        """
  </table>
</body>
</html>""";
    //print(document.outerHtml);

    final bool result =
        await Printing.layoutPdf(onLayout: (PdfPageFormat format) async {
      //final String html = await rootBundle.loadString('assets/example.html');
      //final String html = await rootBundle.loadString(document.outerHtml);
      //return await Printing.convertHtml(format: format, html: html);
      return await Printing.convertHtml(format: format, html: document);
    });

    _showPrintedToast(result);
  }

  Future<void> _printPdf() async {
    print('Print ...');
    try {
      final bool result = await Printing.layoutPdf(
          onLayout: (PdfPageFormat format) async =>
              (await generateDocument(format)).save());
      _showPrintedToast(result);
    } catch (e) {
      final ScaffoldState scaffold = Scaffold.of(shareWidget.currentContext);
      scaffold.showSnackBar(SnackBar(
        content: Text('Error: ${e.toString()}'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff1C1F24),
      appBar: AppBar(
        title: Text(
          'Document List',
          style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold),
        ),
        actions: <Widget>[
          IconButton(
            onPressed: () {
              _printHtml();
            },
            icon: Icon(Icons.print),
          ),
          IconButton(
            onPressed: () {
              _getListDocument();
            },
            icon: Icon(Icons.refresh),
          ),
        ],
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     Navigator.pushReplacement(
      //         context, MaterialPageRoute(builder: (context) => DocumentScan()));
      //   },
      //   child: Icon(
      //     Icons.folder_special,
      //     color: Colors.white,
      //   ),
      // ),
      // body: ListView.builder(
      //   itemBuilder: (c, i) => Padding(
      //     padding: EdgeInsets.symmetric(vertical: 8),
      //     child: makeCardListTrip(),
      //   ),
      //   itemCount: 10,
      // ),
      body: ListView.builder(
        controller: _scrollListDocument,
        itemBuilder: (c, i) => Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: makeCardListDocument(i),
        ),
        itemCount: modelListDocument.itemCount,
      ),
    );
  }

  makeCardListDocument(int i) {
    return Card(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          InkWell(
            onTap: () {
              setState(() {
                rowListDocumentDetail = i;
              });
            },
            child: Container(
              decoration: BoxDecoration(
                  color: Color(0xfff1f1f1),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10),
                  )),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(top: 5, left: 10),
                    child: Text(
                      modelListDocument.items.values.toList()[i].name,
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    ),
                  ),
                  // Container(
                  //   height: 10,
                  // ),
                  // Padding(
                  //   padding: EdgeInsets.only(top: 5, left: 10),
                  //   child: Text(
                  //     modelListDocument.items.values.toList()[i].reference,
                  //     style:
                  //         TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  //   ),
                  // ),
                  Expanded(
                    flex: 1,
                    child: Container(),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 5, right: 6),
                    child: Text(
                      modelListDocument.items.values.toList()[i].receiptNo,
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.lightGreen[300]),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Document',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            modelListDocument.items.values.toList()[i].name,
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Vehicle',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            modelListDocument.items.values.toList()[i].vehicle,
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Driver',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            modelListDocument.items.values.toList()[i].driver,
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Fuel Name',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            modelListDocument.items.values.toList()[i].fuelName,
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Used Quantity',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            (FlutterMoneyFormatter(
                                        amount: double.parse(modelListDocument
                                            .items.values
                                            .toList()[i]
                                            .usedQuantity))
                                    .output
                                    .nonSymbol)
                                .replaceAll('.00', '')
                                .replaceAll(',', '.'),
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Fuel Price',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            'Rp. ' +
                                (FlutterMoneyFormatter(
                                            amount: double.parse(
                                                modelListDocument.items.values
                                                    .toList()[i]
                                                    .fuelPrice))
                                        .output
                                        .nonSymbol)
                                    .replaceAll('.00', '')
                                    .replaceAll(',', '.') +
                                ',-',
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Amount',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            'Rp. ' +
                                (FlutterMoneyFormatter(
                                            amount: double.parse(
                                                modelListDocument.items.values
                                                    .toList()[i]
                                                    .amount))
                                        .output
                                        .nonSymbol)
                                    .replaceAll('.00', '')
                                    .replaceAll(',', '.') +
                                ',-',
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Transaction Time',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            modelListDocument.items.values
                                .toList()[i]
                                .transactionTime,
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Receipt No',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          Text(
                            modelListDocument.items.values
                                .toList()[i]
                                .receiptNo,
                            style: TextStyle(
                                color: Colors.black87, fontSize: 16.0),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Receipt Image',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 15.0,
                            ),
                          ),
                          Container(
                            height: 5.0,
                          ),
                          modelListDocument.items.values
                                      .toList()[i]
                                      .receiptImage
                                      .length >
                                  0
                              ? Image.memory(base64.decode(modelListDocument
                                  .items.values
                                  .toList()[i]
                                  .receiptImage))
                              : Text('NO IMAGE'),
                          Container(
                            height: 25.0,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            visible: rowListDocumentDetail == i,
          ),
          Visibility(
            child: Container(
              height: 50.0,
            ),
            visible: rowListDocumentDetail == i,
          ),
        ],
      ),
    );
  }

  // makeCardListTrip() {
  //   return Card(
  //     child: Column(
  //       mainAxisSize: MainAxisSize.min,
  //       children: <Widget>[
  //         Container(
  //           decoration: BoxDecoration(
  //               color: Color(0xfff1f1f1),
  //               borderRadius: BorderRadius.only(
  //                 topLeft: Radius.circular(10),
  //                 topRight: Radius.circular(10),
  //               )),
  //           child: Row(
  //             crossAxisAlignment: CrossAxisAlignment.center,
  //             children: <Widget>[
  //               Padding(
  //                 padding: EdgeInsets.only(top: 5, left: 10),
  //                 child: Text(
  //                   'Trip:',
  //                   style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
  //                 ),
  //               ),
  //               Padding(
  //                 padding: EdgeInsets.only(top: 5, left: 10),
  //                 child: Text(
  //                   'CT-000003',
  //                   style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
  //                 ),
  //               ),
  //               Expanded(
  //                 flex: 1,
  //                 child: Container(),
  //               ),
  //               Padding(
  //                 padding: EdgeInsets.only(top: 5, right: 6),
  //                 child: Text(
  //                   'Draft',
  //                   style: TextStyle(
  //                       fontSize: 18,
  //                       fontWeight: FontWeight.bold,
  //                       color: Colors.lightGreen),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ),
  //         Padding(
  //           padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
  //           child: Row(
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             mainAxisAlignment: MainAxisAlignment.center,
  //             children: <Widget>[
  //               Expanded(
  //                 child: Container(
  //                   child: Column(
  //                     mainAxisAlignment: MainAxisAlignment.center,
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: <Widget>[
  //                       Text(
  //                         'Operation Start Date',
  //                         style: TextStyle(
  //                           color: Colors.grey,
  //                           fontSize: 17.0,
  //                         ),
  //                       ),
  //                       Container(
  //                         height: 5.0,
  //                       ),
  //                       Text(
  //                         "01 Agustus 2020",
  //                         style:
  //                             TextStyle(color: Colors.black87, fontSize: 18.0),
  //                       )
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //               Expanded(
  //                 child: Container(
  //                   child: Column(
  //                     mainAxisAlignment: MainAxisAlignment.start,
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: <Widget>[
  //                       Text(
  //                         'Operation End Date',
  //                         style: TextStyle(
  //                           color: Colors.grey,
  //                           fontSize: 17.0,
  //                         ),
  //                       ),
  //                       Container(
  //                         height: 5.0,
  //                       ),
  //                       Text(
  //                         "31 Agustus 2020",
  //                         style:
  //                             TextStyle(color: Colors.black87, fontSize: 18.0),
  //                       )
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ),
  //         Padding(
  //           padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
  //           child: Row(
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             mainAxisAlignment: MainAxisAlignment.center,
  //             children: <Widget>[
  //               Expanded(
  //                 child: Container(
  //                   child: Column(
  //                     mainAxisAlignment: MainAxisAlignment.center,
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: <Widget>[
  //                       Text(
  //                         'Vehicle',
  //                         style: TextStyle(
  //                           color: Colors.grey,
  //                           fontSize: 17.0,
  //                         ),
  //                       ),
  //                       Container(
  //                         height: 5.0,
  //                       ),
  //                       Text(
  //                         "Isuzu/NKR 71/KH 2222 BB",
  //                         style:
  //                             TextStyle(color: Colors.black87, fontSize: 18.0),
  //                       )
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //               SizedBox(
  //                 width: 10,
  //               ),
  //               Expanded(
  //                 child: Container(
  //                   child: Column(
  //                     mainAxisAlignment: MainAxisAlignment.start,
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: <Widget>[
  //                       Text(
  //                         'Driver',
  //                         style: TextStyle(
  //                           color: Colors.grey,
  //                           fontSize: 17.0,
  //                         ),
  //                       ),
  //                       Container(
  //                         height: 5.0,
  //                       ),
  //                       Text(
  //                         "Driver 1",
  //                         style:
  //                             TextStyle(color: Colors.black87, fontSize: 18.0),
  //                       )
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ),
  //         Visibility(
  //           child: Padding(
  //             padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
  //             child: Row(
  //               crossAxisAlignment: CrossAxisAlignment.start,
  //               mainAxisAlignment: MainAxisAlignment.center,
  //               children: <Widget>[
  //                 Expanded(
  //                   child: Container(
  //                     child: Column(
  //                       mainAxisAlignment: MainAxisAlignment.center,
  //                       crossAxisAlignment: CrossAxisAlignment.start,
  //                       children: <Widget>[
  //                         InkWell(
  //                           onTap: () {
  //                             //
  //                           },
  //                           child: Container(
  //                             //width: 150,
  //                             width: 100,
  //                             margin: EdgeInsets.symmetric(horizontal: 24),
  //                             decoration: BoxDecoration(
  //                                 borderRadius:
  //                                     BorderRadius.all(Radius.circular(50)),
  //                                 color: Colors.red),
  //                             child: Center(
  //                               child: Padding(
  //                                 padding: EdgeInsets.only(top: 15, bottom: 15),
  //                                 child: Text(
  //                                   "Serah Dokumen",
  //                                   textAlign: TextAlign.center,
  //                                   style: TextStyle(
  //                                       color: Colors.white,
  //                                       fontSize: 18,
  //                                       fontWeight: FontWeight.bold),
  //                                 ),
  //                               ),
  //                             ),
  //                           ),
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                 ),
  //                 SizedBox(
  //                   width: 10,
  //                 ),
  //                 Expanded(
  //                   child: Container(
  //                     child: Column(
  //                       mainAxisAlignment: MainAxisAlignment.start,
  //                       crossAxisAlignment: CrossAxisAlignment.start,
  //                       children: <Widget>[
  //                         InkWell(
  //                           onTap: () {
  //                             //
  //                           },
  //                           child: Container(
  //                             //width: 150,
  //                             width: 100,
  //                             margin: EdgeInsets.symmetric(horizontal: 24),
  //                             decoration: BoxDecoration(
  //                                 borderRadius:
  //                                     BorderRadius.all(Radius.circular(50)),
  //                                 color: Colors.green),
  //                             child: Center(
  //                               child: Padding(
  //                                 padding: EdgeInsets.only(top: 15, bottom: 15),
  //                                 child: Text(
  //                                   "Terima Dokumen",
  //                                   textAlign: TextAlign.center,
  //                                   style: TextStyle(
  //                                       color: Colors.white,
  //                                       fontSize: 18,
  //                                       fontWeight: FontWeight.bold),
  //                                 ),
  //                               ),
  //                             ),
  //                           ),
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           ),
  //           visible: true,
  //         ),
  //       ],
  //     ),
  //   );
  // }

  // makeDecoration(String s) {
  //   return InputDecoration(
  //       labelText: s,
  //       labelStyle: TextStyle(
  //           fontWeight: FontWeight.normal, fontSize: 10, color: Colors.grey));
  // }
}
