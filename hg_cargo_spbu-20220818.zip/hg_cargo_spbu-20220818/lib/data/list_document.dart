//import 'package:flutter/foundation.dart';
//import 'package:flutter/material.dart';

class ListDocumentItem {
  final String id;
  final String name;
  final String vehicle;
  final String driver;
  final String fuelName;
  final String usedQuantity;
  final String fuelPrice;
  final String amount;
  final String transactionTime;
  final String receiptNo;
  final String receiptImage;

  ListDocumentItem({
    this.id,
    this.name,
    this.vehicle,
    this.driver,
    this.fuelName,
    this.usedQuantity,
    this.fuelPrice,
    this.amount,
    this.transactionTime,
    this.receiptNo,
    this.receiptImage,
  });
}

class ListDocument {
  Map<String, ListDocumentItem> _items = {};

  Map<String, ListDocumentItem> get items {
    return _items;
  }

  int get itemCount {
    return _items.length;
  }

  void addItem(
    String id,
    String name,
    String vehicle,
    String driver,
    String fuelName,
    String usedQuantity,
    String fuelPrice,
    String amount,
    String transactionTime,
    String receiptNo,
    String receiptImage,
  ) {
    _items.putIfAbsent(
        id,
        () => ListDocumentItem(
              id: id,
              name: name,
              vehicle: vehicle,
              driver: driver,
              fuelName: fuelName,
              usedQuantity: usedQuantity,
              fuelPrice: fuelPrice,
              amount: amount,
              transactionTime: transactionTime,
              receiptNo: receiptNo,
              receiptImage: receiptImage,
            ));
  }

  void clear() {
    _items = {};
  }
}
