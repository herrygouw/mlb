import 'package:flutter/material.dart';

class Helpers {
  static whiteRoundInputDecoration(String hint) {
    return new InputDecoration(
      contentPadding: EdgeInsets.fromLTRB(10, 15, 10, 15),
      hintStyle: TextStyle(color: Colors.green, fontSize: 22),
      fillColor: Colors.black,
      filled: true,
      hintText: hint,
    );
  }

  static makeDecoration(String s) {
    return InputDecoration(
        labelText: s,
        labelStyle: TextStyle(
            fontWeight: FontWeight.normal, fontSize: 16, color: Colors.grey));
  }


}
