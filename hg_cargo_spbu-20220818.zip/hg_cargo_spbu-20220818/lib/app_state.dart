import 'package:flutter/foundation.dart';

enum State { IDLE, TASK_LIST, ADD_TASK }

class AppStateModel with ChangeNotifier {
  State currentState = State.IDLE;

  void setState(State state) {
    currentState = state;
    notifyListeners();
  }
}
