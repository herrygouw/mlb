/*
 * Copyright 2019 Herry Gouw
 *
 */

import 'dart:async';

import '../utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSharedPreferences {
///////////////////////////////////////////////////////////////////////////////
  static Future<SharedPreferences> getInstance() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs;
  }

///////////////////////////////////////////////////////////////////////////////
  static Future<void> clear() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.clear();
  }

///////////////////////////////////////////////////////////////////////////////
  static Future<bool> isUserLoggedIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getBool(SharedPreferenceKeys.IS_USER_LOGGED_IN);
  }

  static Future<void> setUserLoggedIn(bool isLoggedIn) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setBool(SharedPreferenceKeys.IS_USER_LOGGED_IN, isLoggedIn);
  }

///////////////////////////////////////////////////////////////////////////////
  static Future<String> getUserEmailLoggedIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(SharedPreferenceKeys.USER_EMAIL);
  }

  static Future<void> setUserEmailLoggedIn(String userEmailLoggedIn) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(SharedPreferenceKeys.USER_EMAIL, userEmailLoggedIn);
  }

///////////////////////////////////////////////////////////////////////////////
  static Future<String> getUserPasswordLoggedIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(SharedPreferenceKeys.USER_PASSWORD);
  }

  static Future<void> setUserPasswordLoggedIn(
      String userPasswordLoggedIn) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(
        SharedPreferenceKeys.USER_PASSWORD, userPasswordLoggedIn);
  }

///////////////////////////////////////////////////////////////////////////////
  static Future<String> getPartnerId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(SharedPreferenceKeys.PARTNER_ID);
  }

  static Future<void> setPartnerId(String partnerId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(SharedPreferenceKeys.PARTNER_ID, partnerId);
  }

///////////////////////////////////////////////////////////////////////////////
  static Future<String> getFCM() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(SharedPreferenceKeys.FCM);
  }

  static Future<void> setFCM(String fcmToken) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(SharedPreferenceKeys.FCM, fcmToken);
  }

}
