/*
 * Copyright 2020-2021 Herry Gouw
 *
 */

class AppOdoo {
  // DEV
  static const String odooURL = "https://mlbsys.com";
  static const String odooDatabase = "mockrun2";

  // // PROD
  // static const String odooURL = "https://www.keepsense.com";
  // static const String odooDatabase = "mockrun1";


  //static const String odooDatabase = "ks2";
  //static const String odooURL = "https://www.iamtrack.com";
  //static const String odooDatabase = "mlb-cargo";
  //static const String odooDatabase = "mockrun1";
  //static const String odooURL = "https://www.sarasware.com";
 
  // static const String odooURL = "https://www.keepsense.com";
  // static const String odooDatabase = "mockrun1";
}

class AppStore {
  // static const APP_STORE_URL =
  //   'https://phobos.apple.com/WebObjects/MZStore.woa/wa/viewSoftwareUpdate?id=YOUR-APP-ID&mt=8';
  static const PLAY_STORE_URL =
      'https://play.google.com/store/apps/details?id=com.mlbsys.fodi.merchant.fuel';
  //static const PLAY_STORE_URL_BUILD_NUMBER = 51;
}

///////////////////////////////////////////////////////////////////////////////

class SharedPreferenceKeys {
  static const String IS_USER_LOGGED_IN = "IS_USER_LOGGED_IN";
  static const String USER_EMAIL = "USER_EMAIL";
  static const String USER_PASSWORD = "USER_PASSWORD";
  static const String PARTNER_ID = "PARTNER_ID";
  static const String FCM = "FCM";
}

/////////////////////////////////////////////////////////////////////////////

//var appLANGUAGE = "id";
var appLANGUAGE = "en";

///////////////////////////////////////////////////////////////////////////////
class MLBTextsIndo {
  static const String HOME = "MLB";
  static const String INBOX = "Kotak Masuk";
  static const String TRIP = "Trip";
  static const String HISTORY = "Riwayat";
  static const String PROFILE = "Profil";
  static const String VIEW_TRIP = "Lihat TRIP";
  static const String TRIP_DETAIL = "Detil TRIP";
  static const String TRIP_NO = "TRIP#";
  static const String TRIP_ROUTE = "Rute";
  static const String TRIP_DRIVER = "Supir";
  static const String TRIP_VEHICLE = "Mobil";
  static const String TRIP_START = "Perkiraan Mulai";
  static const String TRIP_END = "Perkiraan Akhir";
  static const String TRIP_PACKAGE = "Paket";
  static const String TRIP_PICKING = "Muat";
  static const String TRIP_DELIVERY = "Bongkar";
  static const String TRIP_STATUS = "Status";
  static const String TRIP_STATUS_NEED_PICKING = "Proses Muat";
  static const String TRIP_STATUS_PICKED = "Sudah Muat";
  static const String TRIP_STATUS_DELIVERED = "Sudah Bongkar";
  static const String TRIP_STATUS_ON_THE_WAY_DELIVERING = "Dalam Perjalanan";
  static const String TRIP_PACKAGE_QTY = "Paket Qty";
  static const String TRIP_PICKED_QTY = "Muat Qty";
  static const String TRIP_DELIVERED_QTY = "Bongkar Qty";
  static const String ARE_YOU_SURE = "Data sudah benar?";
  static const String YES = "YA";
  static const String NO = "TIDAK";
  static const String PHOTO_DOC = "Silahkan Foto Dokumen";
  static const String PHOTO_STRUCK = "Silahkan Foto Struk";
  static const String CURRENT_LOCATION = "Titik Lokasi saat ini";
  static const String CAMERA = "KAMERA";
  static const String REJECT_TRIP = "Tolak Trip";
  static const String ACCEPT_TRIP = "Terima Trip";
  static const String ACCEPT_TRIP_SUCCESS = "TERIMA TRIP BERHASIL !!!";
  static const String START_TRIP = "Mulai Trip";
  static const String START_TRIP_SUCCESS = "START TRIP BERHASIL !!!";
  static const String DONE_TRIP = "Selesai Trip";
  static const String DONE_TRIP_SUCCESS = "SELESAI TRIP BERHASIL !!!";
  static const String ODOMETER = "Odometer";
  static const String ODOMETER_MSG = "Odometer harus diisi";
  static const String REJECT_REASON = "Alasan tolak";
  static const String REJECT_REASON_MSG = "Alasan tolak harus diisi";
  static const String REJECT_TRIP_SUCCESS = "REJECT TRIP BERHASIL !!!";
  static const String PICKING_SUCCESS = "MUAT SELESAI !!!";
  static const String DELIVERY_SUCCESS = "BONGKAR SELESAI !!!";
  static const String NEXT_SCREEN = "LANGKAH SELANJUTNYA";
  static const String INFO = "Informasi";
  static const String INFO_INVALID_LOGIN = "Login gagal\nSilahkan cek kembali";
  static const String INFO_CONNECTION_PROBLEM =
      "Koneksi gagal\nSilahkan cek internet data\nJika Anda pernah diganti passwordnya, harap logout dan login lagi";
  static const String OK = "Okay";
  static const String UPDATE_SUCCESS = "Berhasil simpan data !!!";
  static const String USED_FUEL = "Isi Bensin";
  static const String USED_FUEL_AMOUNT = "Isi Harga";
  static const String CONFIRM_FUEL_SUCCESS = "Isi Bensin BERHASIL !!!";
  static const String CURRENT_POSITION_GPS = "Posisi Saat Ini";
  static const String TASK_ROUTE = "Tugas";
  static const String DEPARTED_ROUTE = "Berangkat";
  static const String DEPARTED_TIME = "Waktu Berangkat";
  static const String VIEW_LIST_PACKAGES = "Lihat Paket";
  static const String EMPTY_LIST_PACKAGES = "Tidak Ada Paket";
  static const String PICKING_LOCATION = "Lokasi Muat";
  static const String DELIVERY_LOCATION = "Lokasi Bongkar";
  static const String QTY = "Kuantitas";
  static const String UOM = "Unit";
  static const String TRIP_PACKAGES = "Paket Perjalanan";
  static const String INFO_PACKAGES = "Informasi Paket";
  static const String PRICE_UNIT = "Ongkos Angkut per Kg";
  static const String SHRINKAGE_TOLERANCES = "Toleransi Susut";
  static const String QTY_TO_INVOICE = "Kuantitas Faktur";
  static const String CONTRACT_NUMBER = "Nomor Kontrak";
  static const String START_TRIP_LOCATION = "Lokasi Berangkat";
  static const String END_TRIP_LOCATION = "Lokasi Tujuan";
  static const String START = "Berangkat";
  static const String END = "Tujuan";
  static const String PROCESS = "Proses";
  static const String CONFIRM = "Konfirmasi";
  static const String SCAN_QR = "Scan QR";
  static const String INVALID_QR = "QR Tidak Valid";
  static const String NOT_VALID_FUEL = "Fuel melebihi alokasi";
  static const String DRIVER_NAME = "Nama Supir";
  static const String LICENSE_PLATE = "Plat";
  static const String NOMOR_STRUK_FUEL = "Nomor Struk";
  static const String INVALID_NOMOR_STRUK_FUEL = "Nomor Struk harus diisi";
  static const String VALIDASI_BRUTO = "Bruto harus lebih besar dari Tarra";
  static const String REMOTE_CONFIG_1 = "Ada Versi Baru";
  static const String REMOTE_CONFIG_2 = "Segera perbaharui sekarang juga";
  static const String REMOTE_CONFIG_3 = "Perbaharui Sekarang";
  static const String REMOTE_CONFIG_4 = "Nanti Saja";
  static const String TIMING_PICKING_DELIVERY_1 = "Minimal 30 menit";
  static const String TIMING_PICKING_DELIVERY_2 =
      "Waktu antara Muat dan Bongkar";
  static const String TRIP_DOCUMENT =
      "Proses Ritase belum selesai.\nDokumen timbang belum bisa diserah terimakan.";
  static const String DRIVER_SIAP_KERJA_1 = "Status anda sekarang:";
  static const String DRIVER_SIAP_KERJA_2 = "Apakah anda akan mengubah status anda menjadi SIAP KERJA?";
  static const String DRIVER_SIAP_KERJA_YA = "SIAP KERJA";
  static const String DRIVER_SIAP_KERJA_TIDAK = "TIDAK SIAP KERJA";
}

class MLBTextsEnglish {
  static const String HOME = "Home";
  static const String INBOX = "Inbox";
  static const String TRIP = "Trip";
  static const String HISTORY = "History";
  static const String PROFILE = "Profile";
  static const String VIEW_TRIP = "View TRIP";
  static const String TRIP_DETAIL = "TRIP Detail";
  static const String TRIP_NO = "TRIP#";
  static const String TRIP_ROUTE = "Route";
  static const String TRIP_DRIVER = "Driver";
  static const String TRIP_VEHICLE = "Vehicle";
  static const String TRIP_START = "Expected Start";
  static const String TRIP_END = "Expected End";
  static const String TRIP_PACKAGE = "Package";
  static const String REJECT_TRIP = "Reject Trip";
  static const String ACCEPT_TRIP = "Accept Trip";
  static const String ACCEPT_TRIP_SUCCESS = "ACCEPT TRIP SUCCESS !!!";
  static const String START_TRIP = "Start Trip";
  static const String START_TRIP_SUCCESS = "START TRIP SUCCESS !!!";
  static const String DONE_TRIP = "Done Trip";
  static const String DONE_TRIP_SUCCESS = "DONE TRIP SUCCESS !!!";
  static const String ODOMETER = "Odometer";
  static const String ODOMETER_MSG = "Odometer should be filled";
  static const String REJECT_REASON = "Reject reason";
  static const String REJECT_REASON_MSG = "Reject reason should be filled";
  static const String REJECT_TRIP_SUCCESS = "REJECT TRIP SUCCESS !!!";
  static const String TRIP_PICKING = "Picking";
  static const String TRIP_DELIVERY = "Delivery";
  static const String TRIP_STATUS = "Status";
  static const String TRIP_STATUS_NEED_PICKING = "Need Picking";
  static const String TRIP_STATUS_PICKED = "Picked";
  static const String TRIP_STATUS_DELIVERED = "Delivered";
  static const String TRIP_STATUS_ON_THE_WAY_DELIVERING =
      "On the way delivering";
  static const String TRIP_PACKAGE_QTY = "Package Qty";
  static const String TRIP_PICKED_QTY = "Picked Qty";
  static const String TRIP_DELIVERED_QTY = "Delivered Qty";
  static const String ARE_YOU_SURE = "Are You Sure?";
  static const String YES = "YES";
  static const String NO = "NO";
  static const String PHOTO_DOC = "Please Photo Your Document";
  static const String PHOTO_STRUCK = "Please Photo Struk";
  static const String CURRENT_LOCATION = "Current Location";
  static const String CAMERA = "CAMERA";
  static const String PICKING_SUCCESS = "PICKING SUCCESS !!!";
  static const String DELIVERY_SUCCESS = "DELIVERY SUCCESS !!!";
  static const String NEXT_SCREEN = "NEXT SCREEN";
  static const String INFO = "Information";
  static const String INFO_INVALID_LOGIN = "Invalid Login\nPlease check again";
  static const String INFO_CONNECTION_PROBLEM =
      "Connection timeout\nPlease check internet data\nif you change your password, please logout and then login again";
  static const String OK = "Ok";
  static const String UPDATE_SUCCESS = "Success Update Data !!!";
  static const String USED_FUEL = "Used Fuel";
  static const String USED_FUEL_AMOUNT = "Fuel Amount";
  static const String CONFIRM_FUEL_SUCCESS = "Fuel Trip Success !!!";
  static const String CURRENT_POSITION_GPS = "Current Position";
  static const String TASK_ROUTE = "Task";
  static const String DEPARTED_ROUTE = "Departed";
  static const String DEPARTED_TIME = "Departure date and time";
  static const String VIEW_LIST_PACKAGES = "View List Package(s)";
  static const String EMPTY_LIST_PACKAGES = "Empty List Package(s)";
  static const String PICKING_LOCATION = "Picking Location";
  static const String DELIVERY_LOCATION = "Delivery Location";
  static const String QTY = "Quantity";
  static const String UOM = "UOM";
  static const String TRIP_PACKAGES = "Trip Package";
  static const String INFO_PACKAGES = "Info Package";
  static const String PRICE_UNIT = "Price Unit per Kg";
  static const String SHRINKAGE_TOLERANCES = "Shrinkage Tolerances";
  static const String QTY_TO_INVOICE = "Qty To Invoice";
  static const String CONTRACT_NUMBER = "Contract Number";
  static const String START_TRIP_LOCATION = "Start Trip Location";
  static const String END_TRIP_LOCATION = "End Trip Location";
  static const String START = "Start";
  static const String END = "End";
  static const String PROCESS = "Process";
  static const String CONFIRM = "Confirm";
  static const String SCAN_QR = "Scan QR";
  static const String INVALID_QR = "Invalid QR";
  static const String NOT_VALID_FUEL = "Fuel more than alocation";
  static const String DRIVER_NAME = "Driver Name";
  static const String LICENSE_PLATE = "License Plate";
  static const String NOMOR_STRUK_FUEL = "Receipt Number";
  static const String INVALID_NOMOR_STRUK_FUEL =
      "Receipt Number cannot be blank";
  static const String VALIDASI_BRUTO = "Bruto should more than Tarra";
  static const String REMOTE_CONFIG_1 = "New Update Available";
  static const String REMOTE_CONFIG_2 =
      "There is a newer version of app available please update it now.";
  static const String REMOTE_CONFIG_3 = "Update Now";
  static const String REMOTE_CONFIG_4 = "Later";
  static const String TIMING_PICKING_DELIVERY_1 = "Minimum 30 minute(s)";
  static const String TIMING_PICKING_DELIVERY_2 =
      "Timing between Picking and Delivery";
  static const String TRIP_DOCUMENT =
      "Trip process is not done yet.\nDocument cannot be tranfer.";
  static const String DRIVER_SIAP_KERJA_1 = "Your status now:";
  static const String DRIVER_SIAP_KERJA_2 = "Are you ready to work now?";
  static const String DRIVER_SIAP_KERJA_YA = "READY TO WORK";
  static const String DRIVER_SIAP_KERJA_TIDAK = "NOT READY TO WORK";
}
///////////////////////////////////////////////////////////////////////////////
