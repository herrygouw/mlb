import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

import '../helpers.dart';

//https://androidkt.com/flutter-alertdialog-example/

void displayDialog(
    BuildContext context, String title, String message, String buttonLabel) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return alertDialog(title, message, buttonLabel, context);
      });
}

alertDialog(
    String title, String message, String buttonLabel, BuildContext context) {
  if (Theme.of(context).platform == TargetPlatform.iOS) {
    return CupertinoAlertDialog(
      title: Text(title),
      content: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Text(message),
      ),
      actions: <Widget>[
        CupertinoDialogAction(
            child: Text(buttonLabel),
            onPressed: () {
              Navigator.of(context).pop();
            })
      ],
    );
  } else {
    return AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: <Widget>[
        FlatButton(
            child: Text(buttonLabel),
            onPressed: () {
              Navigator.of(context).pop();
            }),
      ],
    );
  }
}

void displayDialog1(
    BuildContext context, String title, String message, String buttonLabel) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return alertDialog1(title, message, buttonLabel, context);
      });
}

alertDialog1(
    String title, String message, String buttonLabel, BuildContext context) {
    TextEditingController _controllerMsg = new TextEditingController();
    _controllerMsg.text = message;
  if (Theme.of(context).platform == TargetPlatform.iOS) {
    return CupertinoAlertDialog(
      title: Text(title),
      content: Padding(
        padding: const EdgeInsets.all(15.0),
        child: 
              TextField(
                controller: _controllerMsg,
                style: TextStyle(color: Color(0xff434343)),
                decoration: Helpers.whiteRoundInputDecoration("FCM device token"),
              ),
      ),
      actions: <Widget>[
        CupertinoDialogAction(
            child: Text(buttonLabel),
            onPressed: () {
              Navigator.of(context).pop();
            })
      ],
    );
  } else {
    return AlertDialog(
      title: Text(title),
      content: 
              TextField(
                controller: _controllerMsg,
                style: TextStyle(color: Color(0xff434343)),
                decoration: Helpers.whiteRoundInputDecoration("FCM device token"),
              ),
      actions: <Widget>[
        FlatButton(
            child: Text(buttonLabel),
            onPressed: () {
              Navigator.of(context).pop();
            }),
      ],
    );
  }
}
